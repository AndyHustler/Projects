function CityController () {
    const dataTableSelect = 'Street';
    const selParName = 'street_name';
    
    const dataTable = 'City';
    const inpParId ='city';
    const inpParName = 'city_name';
    const inText = 'городов';
    
    const moduleContent = document.querySelector('.module_content');
    
    moduleContent.innerHTML = 
        `<div class="wite_conteiner" style="text-align:center"><span name="curent_user">Редактирование таблицы ${inText}</span></div>` +
        `<div data-table=${dataTable} class="wite_conteiner">` +
            `<div data-type="where">` +
                
                `<div data-type="where" style="display: flex;">` +
                    `<div id="where_select_text" style="width: 30%;text-align: right;margin-right: 24px;">Выбирите из списка</div>` +
                    `<div id="where_select_fild" style="width: 40%;margin-right: 24px;"></div>` +
                `</div>` +
                
                `<div data-type="where" style="display: flex;">` +
                    `<div id="where_input_text" style="width: 30%;text-align: right;margin-right: 24px;">Введите название или выбирите из списка</div>` +
                    `<div id="where_input_fild" style="width: 40%;margin-right: 24px;"></div>` +
                    `<div id="where_buttons" style="width: 30%;"></div>` +
                `</div>` +
            `</div>` +
            `<div data-type="updata" style="margin-top: 10px;display: flex;">` +
                `<div id="updata_input_text" style="width: 30%;text-align: right;margin-right: 24px;">Изменить название на</div>` +
                `<div id="updata_input_fild" style="width: 40%;margin-right: 24px;"></div>` +
                `<div id="updata_buttons" style="width: 30%;"></div>` +
            `</div>` +
        `</div>` +
        `<div class="wite_conteiner" style="text-align:center"><span name="curent_user">здесь будет таблица</span></div>`;
    
    const whereSelFild = document.getElementById("where_select_fild");
    const selWhere = new XInput();
    const selWhereParam = {
        id:inpParId,
        type:'select',
        name:selParName,
        placeholder:'Выбирите из списка',
        options:['City1','City2']
    };
    whereSelFild.appendChild(selWhere.create(selWhereParam));
    selWhere.setAttribute('data-model',dataTableSelect);
        
    const whereInputFild = document.getElementById("where_input_fild");
    const inpWhere = new XInput();
    const inpWhereParam = {
        id:inpParId,
        type:'datalist',
        name:inpParName,
        placeholder:'Введите наименование',
        options:['City1','City2']
    };
    whereInputFild.appendChild(inpWhere.create(inpWhereParam));
    inpWhere.setAttribute('data-model',dataTable);
    
    const whereButtons = document.getElementById("where_buttons");
    const btnSelect = new XButton("primary", "m", "Найти");
    btnSelect.setAttribute('data-action','select');
    btnSelect.setAttribute('style','width:80px;');
    const btnSave = new XButton("primary", "m", "Сохранить");
    btnSave.setAttribute('data-action','insert');
    btnSave.setAttribute('style','width:100px;');
    const btnDelete = new XButton("outline", "m", "Удалить");
    btnDelete.setAttribute('data-action','delete');
    btnDelete.setAttribute('style','width:80px;');
    whereButtons.appendChild(btnSelect);
    whereButtons.appendChild(btnSave);
    whereButtons.appendChild(btnDelete);
    
/*    
    const contentConteiner = document.createElement('div');
    contentConteiner.className = "content_conteiner";
    const controls = document.createElement('div');
    controls.setAttribute('data-table',dataTable);
    controls.innerHTML = inText;
    const where = document.createElement('div');
    where.setAttribute('data-type','where');
    where.setAttribute('style','display:flex');
    const updata = document.createElement('div');
    updata.setAttribute('data-type','updata');
    updata.setAttribute('style','display:flex');
    controls.appendChild(where);
    controls.appendChild(updata);
    contentConteiner.appendChild(controls);
    const moduleContent = document.querySelector('.module_content');
    moduleContent.appendChild(contentConteiner);
    const btnSelect = new XButton("primary", "m", "Найти");
    btnSelect.setAttribute('data-action','select');
    btnSelect.setAttribute('style','width:80px;');
    const btnSave = new XButton("primary", "m", "Сохранить");
    btnSave.setAttribute('data-action','insert');
    btnSave.setAttribute('style','width:100px;');
    const btnDelete = new XButton("outline", "m", "Удалить");
    btnDelete.setAttribute('data-action','delete');
    btnDelete.setAttribute('style','width:80px;');
    const inpWhere = new XInput();
    const inpWhereParam = {
        id:inpParId,
        type:'datalist',
        name:inpParName,
        placeholder:'Введите наименование',
        //onchange:'SpravSelectUpdate(this.value,this.name)',
        options:['City1','City2']
    };
    where.appendChild(inpWhere.create(inpWhereParam));
    inpWhere.setAttribute('data-model',dataTable);
    where.appendChild(btnSelect);
    where.appendChild(btnSave);
    where.appendChild(btnDelete);
*/
    
    const updataInputFild = document.getElementById("updata_input_fild");
    const inpUpdate = new XInput();
    const inpUpdateParam = {
        type:'input',
        name:inpParName,
        placeholder:'Введите новое наименование',
    };
    updataInputFild.appendChild(inpUpdate.create(inpUpdateParam));
    
    const updataButtons = document.getElementById("updata_buttons");
    inpUpdate.setAttribute('data-model',dataTable);
    const btnUpdate = new XButton("primary", "m", "Заменить");
    btnUpdate.setAttribute('data-action','updete');
    updataButtons.appendChild(btnUpdate);
}
