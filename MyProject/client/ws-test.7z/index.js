MainPage ();

const socket = new WebSocket('ws://localhost:5000/')

socket.onopen = () => {
    socket.send(JSON.stringify({
        action: "connection",
        id: 555,
        username: "Andy"
    }))
}

socket.onmessage = (event) => {
    console.log('Пришло сообщение', event.data);
    const rs = JSON.parse(event.data);
    EventHandler(rs.data);
    
}

socket.onclose = () => {

}

socket.onerror = () => {

}

function EventHandler(dat){
    if (typeof dat === 'undefined') return;
    dat.forEach((v) => {
        city.addOpions(v.street_name,v.id);
    })

}

let model = document.querySelectorAll('[data-table]');
//console.log(model);
model.forEach((e) => {
    /*
    e.onclick = (event) => {
        switch (e.dataset.table) {
            case 'Street':
            case 'City':
                SendMessage (e, event);
                break;
        }
        
    }
    */
});

function SendMessage (e, event) {
    let target = event.target;
    //console.log(target)
        //if (target.tagName !== 'BUTTON') return;
        if (!target.dataset.action) return;
        let msg = {};
        msg["action"] = target.dataset.action;
        msg["table"] = e.dataset.table;
        var div = e.querySelectorAll('[data-type]');
        //console.log(div)
        msg["request"] = {};
        msg.request["where"] = {};
        msg.request["updata"] = {};
        div.forEach((d) =>{
            if (d.dataset.type === 'where'){
                var inpt = d.querySelectorAll(`[data-type="where"] input`);
                //console.log("where")
                //console.log(inpt)
                inpt.forEach((i) => {
                    if (i.value.length > 0) msg.request.where[`${i.name}`] = i.value;
                })
            }
            if (d.dataset.type === 'updata'){
                var inpt = d.querySelectorAll(`[data-type="updata"] input`);
                //console.log("updata")
                //console.log(inpt)
                inpt.forEach((i) => {
                    if (i.value.length > 0) msg.request.updata[`${i.name}`] = i.value;
                })
            }
        })
        /*
        var inpt = document.querySelectorAll(`[data-model=${e.dataset.model}] input`);
        msg["request"] = {"where":{}}
        inpt.forEach((i) => {
            console.log(i.name);
            if (i.value.length > 0) {
                if (i.name === 'updata') {
                    msg.request["updata"] = i.value;
                } else {
                    msg.request.where[`${i.name}`] = i.value;
                }
            }
        })
        */
        msg["admin_name"] = document.getElementsByName('curent_user')[0].innerText;
        console.log('msg2');
        console.log(msg);
        socket.send(JSON.stringify(msg));
}
